var searchData=
[
  ['i2c_5fclose',['I2C_close',['../i2cdriver_8h.html#a097ccdcc5540327f0df6118700a68364',1,'i2cdriver.h']]],
  ['i2c_5fdisable10bitaddressing',['I2C_disable10BitAddressing',['../i2cdriver_8h.html#a1d2c05b3127b4520cc09ee3b80709a8c',1,'i2cdriver.h']]],
  ['i2c_5fenable10bitaddressing',['I2C_enable10BitAddressing',['../i2cdriver_8h.html#abc7c776c69df4882cb483e30eb4404d0',1,'i2cdriver.h']]],
  ['i2c_5fopen',['I2C_open',['../i2cdriver_8h.html#a5df2435ff8cec2b6de06a473cf427864',1,'i2cdriver.h']]],
  ['i2c_5fread',['I2C_read',['../i2cdriver_8h.html#ac9c2d06e7ea0e9c01a840841743b27c5',1,'i2cdriver.h']]],
  ['i2c_5freadtransaction',['I2C_readTransaction',['../i2cdriver_8h.html#a4fb00c476124be12a5484290051cc465',1,'i2cdriver.h']]],
  ['i2c_5fsetslaveaddress',['I2C_setSlaveAddress',['../i2cdriver_8h.html#aa78b1a1354344e7010843cffe962df89',1,'i2cdriver.h']]],
  ['i2c_5fwrite',['I2C_write',['../i2cdriver_8h.html#a4889f4597892b63190e1d9e4dd4bb209',1,'i2cdriver.h']]]
];
