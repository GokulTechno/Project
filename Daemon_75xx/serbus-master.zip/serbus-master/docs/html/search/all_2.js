var searchData=
[
  ['getrh',['getRH',['../i2c__htu21d_8c.html#a8780301999f380379b2fa2491ac6ccc1',1,'i2c_htu21d.c']]],
  ['gettemp',['getTemp',['../i2c__htu21d_8c.html#a49fff5426126b4dcc290715fcde0ea17',1,'i2c_htu21d.c']]]
];
