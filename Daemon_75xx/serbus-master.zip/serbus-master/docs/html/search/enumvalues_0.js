var searchData=
[
  ['spi_5flsbfirst',['SPI_LSBFIRST',['../spidriver_8h.html#a31bd35a1aecbf364e888c14b090ff3d4a183d076e845f5ea5d99465cd6aff505f',1,'spidriver.h']]],
  ['spi_5fmsbfirst',['SPI_MSBFIRST',['../spidriver_8h.html#a31bd35a1aecbf364e888c14b090ff3d4a3fa35f661bf7fbb96c05ff70827553be',1,'spidriver.h']]]
];
